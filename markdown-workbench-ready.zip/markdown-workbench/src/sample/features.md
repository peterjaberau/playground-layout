# Markdown Workbench Features

## Supported Markdown Syntax

### Headings

# Heading 1
## Heading 2
### Heading 3

### Text Formatting

This is **bold text** and this is *italic text*. You can also use ***bold italic***.

This is ~~strikethrough~~ text.

### Links and Images

[Visit GitHub](https://github.com)

[Link to relative file](./getting-started.md)

### Tables (GFM)

| Feature | Support | Status |
|---------|---------|--------|
| Tables | Yes | ✅ |
| Task Lists | Yes | ✅ |
| Strikethrough | Yes | ✅ |
| Autolinks | Yes | ✅ |

### Task Lists

- [x] Completed task
- [ ] Incomplete task
- [x] Another done task
- [ ] Work in progress

### Code

Inline code: `const x = 5;`

```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))
```

### Blockquotes

> This is a blockquote
>
> It can span multiple lines

### Horizontal Rule

---

## Tips

- Use `Ctrl+F` or `Cmd+F` to find text
- Use `Ctrl+H` or `Cmd+H` to find and replace
- Local images display through browser object URLs
- Remote images load from their source servers
