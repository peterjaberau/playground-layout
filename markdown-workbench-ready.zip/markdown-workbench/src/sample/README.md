# Sample Files

This folder contains sample markdown files to help you explore Markdown Workbench features.

## Files Included

### 📄 getting-started.md
A quick introduction to Markdown Workbench with basic markdown examples.

### 📄 features.md
Showcases all supported markdown syntax including:
- Headings, text formatting, links
- Tables (GitHub Flavored Markdown)
- Task lists
- Code blocks with syntax highlighting
- Blockquotes and more

### 📄 notes.md
Example study notes with JavaScript concepts, project progress tracking, and reading lists.

### 📄 project-plan.md
A project management document with phases, team structure, risk analysis, and success metrics.

## How to Explore

1. Click on files in the drawer to view them
2. Switch between **Source** and **Preview** modes using the toolbar
3. Try opening multiple files side-by-side (desktop version)
4. Edit the content and save with Ctrl+S / Cmd+S

## Tips

- 💡 These files showcase all supported markdown features
- 🔍 Use Ctrl+F to search within files
- 🎨 Switch themes in settings
- 📱 Try on mobile to see the responsive layout

Enjoy exploring! 🚀
