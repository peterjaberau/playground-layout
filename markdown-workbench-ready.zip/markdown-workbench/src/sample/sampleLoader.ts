import type { WorkspaceDocument } from '../domain/workspace'

// Import sample markdown files
import gettingStartedMd from './getting-started.md?raw'
import featuresMd from './features.md?raw'
import notesMd from './notes.md?raw'
import projectPlanMd from './project-plan.md?raw'
import readmeMd from './README.md?raw'

interface SampleFile {
  name: string
  path: string
  content: string
}

const sampleFiles: SampleFile[] = [
  { name: 'README.md', path: 'sample/README.md', content: readmeMd },
  { name: 'getting-started.md', path: 'sample/getting-started.md', content: gettingStartedMd },
  { name: 'features.md', path: 'sample/features.md', content: featuresMd },
  { name: 'notes.md', path: 'sample/notes.md', content: notesMd },
  { name: 'project-plan.md', path: 'sample/project-plan.md', content: projectPlanMd },
]

export function loadSampleDocuments(): WorkspaceDocument[] {
  const now = Date.now()

  return sampleFiles.map((file, index) => ({
    id: `sample-${index}-${file.name.replace(/[^a-z0-9]/gi, '-')}`,
    name: file.name,
    virtualPath: file.path,
    text: file.content,
    savedText: file.content,
    dirty: false,
    sourceKind: 'fallback' as const,
    viewMode: 'preview' as const,
    updatedAt: now,
  }))
}
