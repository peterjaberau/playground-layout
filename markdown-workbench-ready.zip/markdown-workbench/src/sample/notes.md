# My Study Notes

## JavaScript Concepts

### Variables and Constants

Variables in JavaScript can be declared with:
- `var` - function-scoped (avoid in modern code)
- `let` - block-scoped, reassignable
- `const` - block-scoped, constant

```javascript
const PI = 3.14159;
let counter = 0;
var oldStyle = "avoid this";
```

### Arrow Functions

Arrow functions provide a concise syntax:

```javascript
// Traditional function
function add(a, b) {
  return a + b;
}

// Arrow function
const add = (a, b) => a + b;

// With body
const multiply = (a, b) => {
  const result = a * b;
  return result;
};
```

## Project Progress

| Task | Priority | Status | Due Date |
|------|----------|--------|----------|
| Learn JavaScript | High | 🔄 In Progress | 2026-12-01 |
| Build React App | High | ⏳ Planned | 2026-12-15 |
| Deploy Project | Medium | ⏳ Planned | 2026-12-31 |

## Reading List

- [ ] "Eloquent JavaScript" - Marijn Haverbeke
- [ ] MDN JavaScript Guide
- [x] "You Don't Know JS Yet" - Kyle Simpson (started)
- [ ] Clean Code Principles

## Useful Resources

- [MDN Web Docs](https://developer.mozilla.org)
- [JavaScript.info](https://javascript.info)
- [Can I Use?](https://caniuse.com)

---

*Last updated: 2026-11-19*
