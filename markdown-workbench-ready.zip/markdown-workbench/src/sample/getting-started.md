# Getting Started with Markdown Workbench

Welcome to **Markdown Workbench**! This is a local-first Markdown editor that runs entirely in your browser.

## Key Features

- 📝 **Edit Markdown** - Write and format markdown with syntax highlighting
- 👀 **Preview** - Switch between source and preview modes
- 📂 **Multi-Document** - Open multiple files side-by-side
- 💾 **Local-First** - Your files stay on your device
- 🎨 **Dark/Light Theme** - Follow your system preferences

## Quick Start

1. Click "Open File" or "Open Folder" at the top
2. Select a markdown file from your computer
3. Use the toolbar to switch between **Source** and **Preview** modes
4. Edit and save with `Ctrl+S` or `Cmd+S`

## Example Content

Here's what you can do with markdown:

### Lists

- Item one
- Item two
  - Nested item
  - Another nested item

### Code Blocks

```javascript
function hello(name) {
  console.log(`Hello, ${name}!`);
}

hello('World');
```

### Quotes

> "The best way to predict the future is to invent it."
> — Alan Kay

Enjoy using Markdown Workbench! 🚀
